public class Insertionsort {
    static int num_trocas = 0;
    static int num_iteracoes = 0;
    
	public static void insertionsort(int[] vetor) {
        int aux, j;
        for(int i=1; i < vetor.length; i++){
        	num_iteracoes++;
            aux = vetor[i];
            j = i-1; 
            while(j >= 0 && vetor[j] > aux){
            	num_trocas++;
            	num_iteracoes++;
                vetor[j+1] = vetor[j];
                j--;
            }
            vetor[j+1] = aux;
        	num_trocas++;
        }
	}
}
