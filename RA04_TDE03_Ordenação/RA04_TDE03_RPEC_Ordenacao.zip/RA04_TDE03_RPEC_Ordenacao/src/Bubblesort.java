

public class Bubblesort {
		
    static int num_trocas = 0;
    static int num_iteracoes = 0;	
	
	static void bubblesort(int[] vetor) {
	    int tamanho = vetor.length;
	    int timeless = 0;
	    boolean troca;
	    for(int i = 0; i < tamanho; i++) {
            num_iteracoes++;
	    	troca = false;
	    	for(int j = 1; j < (tamanho - i); j++) {
                num_iteracoes++;
	    		if(vetor[j-1] > vetor[j]) {
	    			timeless = vetor[j-1];
	    			vetor[j-1] = vetor[j];
	    			vetor[j] = timeless;
					num_trocas++;
	    			troca = true;
	    		}
	    	}
	    	if(troca == false) {
	    		break;
	    	}
	    }
	}

}
