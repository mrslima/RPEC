public class Quicksort {
    static int num_trocas = 0;
    static int num_iteracoes = 0;

    static void quicksort(int[] vetor, int esquerda, int direita) {
        if (esquerda < direita) {
            int p = particao(vetor, esquerda, direita);
            quicksort(vetor, esquerda, p);
            quicksort(vetor, p + 1, direita);
        }
    }

    static int particao(int[] vetor, int esquerda, int direita) {
        int pivot = vetor[esquerda];
        int i = esquerda - 1;
        int j = direita + 1;
        while (true) {
            do {
                i++;
                num_iteracoes++;
            } while (vetor[i] < pivot);
            do {
                j--;
                num_iteracoes++;
            } while (vetor[j] > pivot);
            if (i >= j) {
                return j;
            }
            num_trocas++;
            int aux = vetor[i];
            vetor[i] = vetor[j];
            vetor[j] = aux;
        }
    }
}
