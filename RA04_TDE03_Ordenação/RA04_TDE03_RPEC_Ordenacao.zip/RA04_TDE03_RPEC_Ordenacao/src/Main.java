import java.util.Random;

public class Main {
    public static void main(String[] args) {
        int[] test_vet = {50, 500, 1000, 5000, 10000};
        int seed = 102023;
        
     // QUICKSORT
        for (int j : test_vet) {
            int[] resultados_tempo = new int[5];
            int[] resultados_trocas = new int[5];
            int[] resultados_iteracoes = new int[5];

            System.out.println("\n\n----------------------------------------");
            System.out.printf("[QUICKSORT] Teste com %d elementos\n", j);
            System.out.println("----------------------------------------");
            for (int i = 0; i < 5; i++) {
                long resultado = callQuicksort(j, seed);
                resultados_tempo[i] = (int) Math.abs(resultado);
                resultados_trocas[i] = Math.abs(Quicksort.num_trocas);
                resultados_iteracoes[i] = Math.abs(Quicksort.num_iteracoes);
            }
            int tempo_exe = (int) calcularMedia(resultados_tempo);
            int num_trocas = (int) calcularMedia(resultados_trocas);
            int num_iteracoes = (int) calcularMedia(resultados_iteracoes);

            long mili_tempo_exe = tempo_exe;

            System.out.println("Tempo de execução em ms: " + mili_tempo_exe);
            System.out.println("Número de trocas: " + num_trocas);
            System.out.println("Número de iterações: " + num_iteracoes);
        }
        
        
        // INSERTIONSORT
        for (int j : test_vet) {
            int[] resultados_tempo = new int[5];
            int[] resultados_trocas = new int[5];
            int[] resultados_iteracoes = new int[5];
            
        	System.out.println("\n\n----------------------------------------");
        	System.out.printf("[INSERTIONSORT] Teste com %d elementos\n", j);
        	System.out.println("----------------------------------------");
            for (int i=0; i<5; i++) {                
                long resultado = callInsertionsort(j, seed);
                resultados_tempo[i] = (int) Math.abs(resultado);
                resultados_trocas[i] = Math.abs(Insertionsort.num_trocas);
                resultados_iteracoes[i] = Math.abs(Insertionsort.num_iteracoes);
            }
            
            int tempo_exe = (int) calcularMedia(resultados_tempo);
            int num_trocas = (int) calcularMedia(resultados_trocas);
            int num_iteracoes = (int) calcularMedia(resultados_iteracoes);

            long mili_tempo_exe = tempo_exe;

            System.out.println("Tempo de execução em ms: " + mili_tempo_exe);
            System.out.println("Número de trocas: " + num_trocas);
            System.out.println("Número de iterações: " + num_iteracoes);
        }
        
        // BUBBLESORT
        for (int j : test_vet) {
            int[] resultados_tempo = new int[5];
            int[] resultados_trocas = new int[5];
            int[] resultados_iteracoes = new int[5];
            
        	System.out.println("\n\n----------------------------------------");
        	System.out.printf("[BUBBLESORT] Teste com %d elementos\n", j);
        	System.out.println("----------------------------------------");
            for (int i=0; i<5; i++) {                
                long resultado = callBubblesort(j, seed);
                resultados_tempo[i] = (int) Math.abs(resultado);
                resultados_trocas[i] = Math.abs(Bubblesort.num_trocas);
                resultados_iteracoes[i] = Math.abs(Bubblesort.num_iteracoes);
            }
            int tempo_exe = (int) calcularMedia(resultados_tempo);
            int num_trocas = (int) calcularMedia(resultados_trocas);
            int num_iteracoes = (int) calcularMedia(resultados_iteracoes);

            long mili_tempo_exe = tempo_exe;

            System.out.println("Tempo de execução em ms: " + mili_tempo_exe);
            System.out.println("Número de trocas: " + num_trocas);
            System.out.println("Número de iterações: " + num_iteracoes);
        }
        
        // MERGESORT
        for (int j : test_vet) {
            int[] resultados_tempo = new int[5];
            int[] resultados_trocas = new int[5];
            int[] resultados_iteracoes = new int[5];
            
        	System.out.println("\n\n----------------------------------------");
        	System.out.printf("[MERGESORT] Teste com %d elementos\n", j);
        	System.out.println("----------------------------------------");
            for (int i=0; i<5; i++) {                
                long resultado = callMergesort(j, seed);
                resultados_tempo[i] = (int) Math.abs(resultado);
                resultados_trocas[i] = Math.abs(Mergesort.num_trocas);
                resultados_iteracoes[i] = Math.abs(Mergesort.num_iteracoes);
            }
            int tempo_exe = (int) calcularMedia(resultados_tempo);
            int num_trocas = (int) calcularMedia(resultados_trocas);
            int num_iteracoes = (int) calcularMedia(resultados_iteracoes);

            long mili_tempo_exe = tempo_exe;

            System.out.println("Tempo de execução em ms: " + mili_tempo_exe);
            System.out.println("Número de trocas: " + num_trocas);
            System.out.println("Número de iterações: " + num_iteracoes);
        }
    }
    
    static long calcularMedia(int[] array) {
    	int soma = 0;
    	for (int i : array)
    		soma += i;

    	return soma / array.length;
    }
   
    static int[] populaVetor(int seed, int tamanho_vetor) {
    	// Popula vetor com X elementos
    	int[] vetor = new int[tamanho_vetor];
    	Random random = new Random(seed); // Cria um objeto Random com a semente especificada
    	
    	for (int i = 0; i < vetor.length; i++) {
    		vetor[i] = random.nextInt(); // Gere números aleatórios usando o objeto Random
    	}
		return vetor;
    }
    
    static long callQuicksort(int tamanho_vetor, int seed) {
    	int[] vetor = populaVetor(tamanho_vetor, seed);
        
        // Mede tempo de execução
        long start_time = System.currentTimeMillis();
        Quicksort.quicksort(vetor, 0, vetor.length - 1);
        long end_time = System.currentTimeMillis(); 

        long tempo_exe = end_time - start_time;
		return tempo_exe;
    }    
    
    static long callInsertionsort(int tamanho_vetor, int seed) {
    	int[] vetor = populaVetor(tamanho_vetor, seed);
    	
    	// Mede tempo de execução
    	long start_time = System.currentTimeMillis();
    	Insertionsort.insertionsort(vetor);
    	long end_time = System.currentTimeMillis(); 
    	
    	long tempo_exe = end_time - start_time;
    	return tempo_exe;
    }    
    
    static long callBubblesort(int tamanho_vetor, int seed) {
    	int[] vetor = populaVetor(tamanho_vetor, seed);
    	
    	// Mede tempo de execução
    	long start_time = System.currentTimeMillis();
    	Bubblesort.bubblesort(vetor);
    	long end_time = System.currentTimeMillis(); 
    	
    	long tempo_exe = end_time - start_time;
    	return tempo_exe;
    }    
    
    static long callMergesort(int tamanho_vetor, int seed) {
    	int[] vetor = populaVetor(tamanho_vetor, seed);
    	
    	// Mede tempo de execução
    	long start_time = System.currentTimeMillis();
    	Mergesort.mergesort(vetor, 0, vetor.length - 1);
    	long end_time = System.currentTimeMillis(); 
    	
    	long tempo_exe = end_time - start_time;
    	return tempo_exe;
    }    
}
