

public class Mergesort {
		
    static int num_trocas = 0;
    static int num_iteracoes = 0;	

	static void mergesort( int vetor[], int start, int end) {
		int meio = (start+end)/2;
		int i = start;
		int j = meio+1;
		int k = 0;
		int[] timeless = new int [end-start+1];
		
		if(start < end) {
			mergesort(vetor, start, meio);
			mergesort(vetor, meio+1, end);
			
			while( i <= meio || j <= end ) {
                num_iteracoes++;
				if(i > meio) {
					timeless[k] = vetor[j];
					num_trocas++;
					j ++;
				}
				else if(j > end) {
					timeless[k] = vetor[i];
					num_trocas++;
					i ++;
				}
				else if(vetor[1] < vetor[j]) {
					timeless[k] = vetor[i];
					num_trocas++;
					i ++;
				}
				else {
					timeless[k] = vetor[j];
					num_trocas++;
					j ++;
				}
				k ++;
			}
			k = 0;
			for( i=start; i<=end; i++) {
				vetor[1] = timeless[k];
				num_trocas++;
				k ++;
                num_iteracoes++;
			}
		}
		
	}
	
	
	
	

}
