import java.util.Random;

public class Main {
    public static void main(String[] args) {
        int[] test_vet = {10, 100, 1000, 10000, 1000000};
        int seed = 123;
        
        for (int j : test_vet) {
        	TabelaHash tabela = new TabelaHash(j);
        	
            popularTabela(tabela, seed, 20000, "dobramento");
            popularTabela(tabela, seed, 20000, "multiplicacao");
            popularTabela(tabela, seed, 20000, "resto");


            medirTempoDeBusca(tabela, 5, 123456789, "dobramento");
            medirTempoDeBusca(tabela, 5, 123456789, "multiplicacao");
            medirTempoDeBusca(tabela, 5, 123456789, "resto");
        }
    }

    public static void popularTabela(TabelaHash tabela, long seed, int quantidade, String metodo) {
    Random random = new Random(seed);
    int colisoesAntes = tabela.getColisoes();
    long startTime = System.nanoTime();

    for (int i = 0; i < quantidade; i++) {
        int numero = random.nextInt(1000000000);
        Registro registro = new Registro(numero);

        if (metodo.equals("dobramento")) {
            tabela.inserirDobramento(registro);
        } else if (metodo.equals("multiplicacao")) {
            tabela.inserirMultiplicacao(registro, 0.6);
        } else {
            tabela.inserirResto(registro);
        }
    }

    long endTime = System.nanoTime();
    int colisoesDepois = tabela.getColisoes() - colisoesAntes;

    System.out.println("Tamanho da tabela: " + tabela.getTamanho());
    System.out.println("Método de inserção: " + metodo);
    System.out.println("Tempo necessário (ns) para população: " + (endTime - startTime));
    System.out.println("Número de colisões durante a população: " + colisoesDepois);
    System.out.println();
}

    public static void medirTempoDeBusca(TabelaHash tabela, int qtdBuscas, int valorBusca, String metodo) {
        long somaDosTempos = 0;

    for (int i = 0; i < qtdBuscas; i++) {
        long startTime = System.nanoTime();
        if (metodo.equals("resto")) {
            tabela.buscar(valorBusca);
        } else if (metodo.equals("dobramento")) {
            tabela.buscarDobramento(valorBusca);
        } else {
            tabela.buscarMultiplicacao(valorBusca);
        }
        long endTime = System.nanoTime();
        somaDosTempos += (endTime - startTime);
    }

    long mediaDosTempos = somaDosTempos / qtdBuscas;

    System.out.println("Média de tempo (ns) para realizar " + qtdBuscas + " buscas com método " + metodo + ": " + mediaDosTempos);
}
}
