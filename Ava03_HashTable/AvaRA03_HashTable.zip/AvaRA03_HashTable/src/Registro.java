public class Registro {
    private int numero;
    private Registro proximo;
    private Registro anterior;

    public Registro(int numero) {
        this.numero = numero;
    }

    public int getNumero() {
        return numero;
    }
    public Registro getAnterior(){
        return anterior;
    }
    public void setAnterior(Registro numero) {
        this.anterior = numero;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Registro getProximo() {
        return proximo;
    }

    public void setProximo(Registro proximo) {
        this.proximo = proximo;
    }
}
