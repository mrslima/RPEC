public class TabelaHash {
    private int tamanho;
    private int colisoes;
    private Registro[] tabela;
    
    public TabelaHash(int tamanho) {
        this.tamanho = tamanho;
        this.tabela = new Registro[tamanho];
    }
    
    public void inserirResto(Registro chave) {
    int x = chave.getNumero() % tamanho;
    
    if (tabela[x] == null) {
        tabela[x] = chave;
        tabela[x].setAnterior(null);
    } else {
        colisoes++;
        Registro y = tabela[x];

        while (y.getProximo() != null && chave.getNumero() > y.getNumero()) {
            y = y.getProximo();
        }

        if (chave.getNumero() < y.getNumero()) {
            // Inserir antes de y
            if (y.getAnterior() != null) {
                y.getAnterior().setProximo(chave);
                chave.setAnterior(y.getAnterior());
            } else {
                tabela[x] = chave;
                chave.setAnterior(null);
            }

            y.setAnterior(chave);
            chave.setProximo(y);
        } else {
            // Inserir no final da lista
            y.setProximo(chave);
            chave.setAnterior(y);
            
        }
    }
}

    public int getColisoes(){return this.colisoes;}
    public int getTamanho(){return this.tamanho;}

      
    public void inserirDobramento(Registro chave) {
        int x = dobramento(chave.getNumero(), tamanho);

        if (tabela[x] == null) {
            tabela[x] = chave;
            tabela[x].setAnterior(null);
        } else {
            colisoes++;
            Registro y = tabela[x];
            while (y.getProximo() != null && chave.getNumero() > y.getNumero()) {
            y = y.getProximo();
        }

        if (chave.getNumero() < y.getNumero()) {
            // Inserir antes de y
            if (y.getAnterior() != null) {
                y.getAnterior().setProximo(chave);
                chave.setAnterior(y.getAnterior());
            } else {
                tabela[x] = chave;
                chave.setAnterior(null);
            }

            y.setAnterior(chave);
            chave.setProximo(y);
        } else {
            // Inserir no final da lista
            y.setProximo(chave);
            chave.setAnterior(y);
        }
    }
    }

    public void inserirMultiplicacao(Registro chave, double A) {
        double valor = chave.getNumero() * A;
        double fracionaria = valor - Math.floor(valor); // Parte fracionária
        int x = (int) (tamanho * fracionaria);
        if (tabela[x] == null) {
            tabela[x] = chave;
            tabela[x].setAnterior(null);
        } else {
            colisoes++;
            Registro y = tabela[x];
            while (y.getProximo() != null && chave.getNumero() > y.getNumero()) {
            y = y.getProximo();
        }

        if (chave.getNumero() < y.getNumero()) {
            // Inserir antes de y
            if (y.getAnterior() != null) {
                y.getAnterior().setProximo(chave);
                chave.setAnterior(y.getAnterior());
            } else {
                tabela[x] = chave;
                chave.setAnterior(null);
            }

            y.setAnterior(chave);
            chave.setProximo(y);
        } else {
            // Inserir no final da lista
            y.setProximo(chave);
            chave.setAnterior(y);
        }
    }
    }

    public Registro buscar(int numero) {
        int x = numero % tamanho;
        Registro y = tabela[x];
        while (y != null) {
            if (y.getNumero() == numero) {
                return y;
            }
            y = y.getProximo();
        }
        return null;
    }
    
    public Registro buscarDobramento(int numero) {
    int x = dobramento(numero, tamanho);
    Registro y = tabela[x];
    
    // Percorrer a lista encadeada para encontrar o registro desejado
    while (y != null) {
        if (y.getNumero() == numero) {
            return y; // Encontrou o registro
        }
        y = y.getProximo();
    }
    return null; // Registro não encontrado
}

// Função de dobramento que calcula o índice de busca
private int dobramento(int numero, int tamanho) {
    int indice = 0;
    int valor = numero;
    

    for (int i = 0; i < 9; i++) {
        int resto = valor % 10;
        valor = valor / 10;
        indice += resto;
      
    }

    return indice % tamanho;
}

public Registro buscarMultiplicacao(int numero) {
    // Calcular o índice de busca usando o método de multiplicação
    int x = multiplicacao(numero, tamanho, 0.5); 
    Registro y = tabela[x];
    
    // Percorrer a lista encadeada para encontrar o registro desejado
    while (y != null) {
        if (y.getNumero() == numero) {
            return y; // Encontrou o registro
        }
        y = y.getProximo();
    }
    return null; // Registro não encontrado
}

// Função de multiplicação que calcula o índice de busca
private int multiplicacao(int numero, int tamanho, double A) {
    double valor = numero * A;
    double fracionaria = valor - Math.floor(valor); // Parte fracionária
    return (int) (tamanho * fracionaria);
}

}